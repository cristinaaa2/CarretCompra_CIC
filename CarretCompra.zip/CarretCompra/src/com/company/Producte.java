package com.company;

/**
 * Classe Per gestionar les dades del productes
 */
public abstract class Producte {
	private float preu;
	private String nom;
	private String codibarres;

	/**
	 * Funcio on es guarden les dades en variables
	 * @param preu preu del producte
	 * @param nom nom del producte
	 * @param codi codi de barres del producte
	 */
	public Producte(float preu, String nom, String codi) {
		this.preu = preu;
		this.nom = nom;
		codibarres = codi;
	}

	/**
	 * Funcio per agafar el preu
	 * @return numero decimal que equival al preu.
	 */
	public float getPreu() {
		return preu;
	}

	public void setPreu(float preu) {
		this.preu = preu;
	}
	/**
	 * Funcio per agafar el nom.
	 * @return string que equival al nom.
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * Funcio que canvia el nom del propi objecte
	 * @param nom string que equival al nom.
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * Funcio per agafar el codi de barres.
	 * @return string que equival al codi de barres.
	 */
	public String getCodibarres() {
		return codibarres;
	}
	/**
	 * Funcio que canvia el codi de barres del propi objecte
	 * @param codibarres string que equival al nom.
	 */
	public void setCodibarres(String codibarres) {
		this.codibarres = codibarres;
	}

	/**
	 * Funcio que comprova si el objeste son iguals
	 * @param obj objecte
	 * @return boolean dient si es igual o no.
	 */
	@Override
	public boolean equals(Object obj) {
		//REFACT: Metode Inline Temp he tret la variable boolean on es guardava el resoltat de la condicio.
		if(obj == null) {
			return false;
		}
		else {
			Producte p = (Producte) obj;
			//REFACT: Metode Inline Code ho he aplicat en caquesta condicio.
			return (codibarres.equals(p.getCodibarres()) && getPreu() == p.getPreu()) ? true : false;
		}
	}

	/**
	 * Comprova si es un codi de barres.
	 * @return numero enter que equival al codi.
	 */
	@Override
	public int hashCode() {
		int codi = codibarres.hashCode();
		return codi;
	}
	
	
	

}
