package com.company;

/**
 * Classe on gestiona les dades de els productes electronics
 */
public class Electronica extends Producte {
	private int dies_garantia;

	/**
	 * Constructor crea un objecte
	 * @param preu numero enter que equival al preu
	 * @param nom string que equival al nom
	 * @param codi string que equival al codi de barres
	 * @param diesg numero enter que equival als dies de garantia
	 */
	public Electronica(float preu, String nom, String codi, int diesg) {
		super(preu, nom, codi);
		dies_garantia = diesg;
	}

	/**
	 * Funcio per agafar el preu.
	 * @return numero decimal que equival al preu
	 */
	@Override
	public float getPreu() {
		float preu = super.getPreu();
		return (float) (preu + preu*(dies_garantia/365)*0.1);
	}

	/**
	 * Funcio que uneix tot en un String
	 * @return string
	 */
	@Override
	public String toString() {
		return getNom() + "," + getPreu();
	}
	
	
	

}
