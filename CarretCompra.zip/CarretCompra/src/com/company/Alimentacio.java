package com.company;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
/**
 * Classe Per gestionar les dades dels productes alimentacio
 */
public class Alimentacio extends Producte {
	
	private LocalDate d;
	/**
	 * Constructor crea un objecte
	 * @param preu numero enter que equival al preu
	 * @param nom string que equival al nom
	 * @param codi string que equival al codi de barres
	 * @param datac numero enter que equival a la data de caducitat
	 */
	public Alimentacio(float preu, String nom, String codi, LocalDate datac) {
		super(preu, nom, codi);
		d = datac; //obtenim la data de caducitat
	}

	/**
	 * Funcio per agafar el preu i calcular la diferencia.
	 * @return numero decimal que equival al preu
	 */
	@Override
	public float getPreu() {
		float preu = super.getPreu();
		//REFACT: Mètode Extracció de Variable canviar el nom de la variable dif per diferencia
		long diferencia;
		diferencia = ChronoUnit.DAYS.between(d,LocalDate.now());
		preu = preu - (float) (preu*(1/(diferencia+1)) + (preu*(0.1)));
		//System.out.println("preu:" + preu);
		return preu;
	}
	/**
	 * Funcio que uneix tot en un String
	 * @return string
	 */
	@Override
	public String toString() {
		return new String(getNom() + " " + getPreu());
	}
	


}
