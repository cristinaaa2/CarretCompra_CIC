package com.company;
/**
 * Classe Per gestionar les dades dels productes textils
 */
public class Textil extends Producte {
	private String composicio;
	private String codificacio;
	/**
	 * Constructor crea un objecte
	 * @param preu numero enter que equival al preu
	 * @param nom string que equival al nom
	 * @param codi string que equival al codi de barres
	 * @param composicio String que equival a la composisio
	 */
	public Textil(float preu, String nom, String codi, String composicio) {
		super(preu, nom, codi);
		composicio = composicio;
		codificacio = preu + codi;
	}

	/**
	 * Fucnio que retorna composisio
	 * @return String composisio
	 */
	public String getComposicio() {
		return composicio;
	}
	/**
	 * Funcio que canvia la composicio del propi objecte
	 * @param composicio string que equival al nom.
	 */
	public void setComposicio(String composicio) {
		this.composicio = composicio;
	}
	/**
	 * Funcio que uneix tot en un String
	 * @return string
	 */
	@Override
	public String toString() {
		return new String(getNom() + " " + getPreu());
	}
	/**
	 * Fucnio que retorna codificacio
	 * @return String codificacio
	 */
	//aquesta funció no s'està usant
	public String getCode (){
		return codificacio;
	}

}
